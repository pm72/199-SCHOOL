kilometres = 14
miles = kilometres/1.6
minutes = 45.5
print ((14*5/8)/(45.5*1/60))
