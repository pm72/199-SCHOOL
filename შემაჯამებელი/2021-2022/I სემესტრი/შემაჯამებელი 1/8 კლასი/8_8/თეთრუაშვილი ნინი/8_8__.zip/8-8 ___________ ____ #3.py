import random
n = random.randint(100,1000)
minutes = n//60
seconds = n%60
print (n, minutes, seconds)
