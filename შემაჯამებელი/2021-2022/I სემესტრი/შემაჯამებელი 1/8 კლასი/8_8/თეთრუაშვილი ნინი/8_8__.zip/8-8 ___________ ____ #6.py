n=12.512
k=3.98j
t=n+k
print (t/2)
