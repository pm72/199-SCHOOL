import math
x2=5
x1=6
y1=5
y2=9
print(math.sqrt((x2-x1)**2+(y2-y1)**2))
