import math
a1 = 100
a2 = 200
b1 = 300
b2 = 400
print(math.sqrt((a2 - a1)**2 + (b2 - b1)**2))
