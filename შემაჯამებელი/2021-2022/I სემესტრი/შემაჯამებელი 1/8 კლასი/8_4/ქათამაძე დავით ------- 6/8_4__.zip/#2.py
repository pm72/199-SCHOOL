a = 14
b = a * 1.6
c = 45.5/60
print(b/c)
