import random
a = random.randint(100,999)
b = a//60
c = a - b*60
print(a,b,c)
