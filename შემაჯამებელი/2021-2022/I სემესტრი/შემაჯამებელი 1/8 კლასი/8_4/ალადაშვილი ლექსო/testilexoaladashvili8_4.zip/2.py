print(str(14.0/1.6/45.5* 60) + "miles per hour")
