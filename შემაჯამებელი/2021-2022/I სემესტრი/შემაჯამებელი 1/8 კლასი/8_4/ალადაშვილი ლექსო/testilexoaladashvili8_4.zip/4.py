a = 2.59
b = -8.92
d = 2*b/pow(a,b)
c = (a-2*b)/pow(d,2)
r = (2.79*a+3*d)/(pow(b,2)-2*a*c)
print(4/(3*(r+34))-9*(a+b*c)+(3+d*(2+a))/(a+b*d))
