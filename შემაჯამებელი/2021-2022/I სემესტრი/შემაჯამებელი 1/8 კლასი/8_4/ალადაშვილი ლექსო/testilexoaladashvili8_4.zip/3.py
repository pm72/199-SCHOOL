import random
a = random.randint(100, 999)
print(str(a//60) + " minutes and " + str(a%60) + " seconds")
