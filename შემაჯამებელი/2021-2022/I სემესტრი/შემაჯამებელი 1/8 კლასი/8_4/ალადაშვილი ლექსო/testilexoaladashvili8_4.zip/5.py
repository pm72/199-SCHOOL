import math
x2 = input("sheiyvanet x2")
x1 = input("sheiyvanet x1")
y2 = input("sheiyvanet y2")
y1 = input("sheiyvanet y1")
print(math.sqrt(pow(x2-x1,2)+pow(y2-y1,2)))
