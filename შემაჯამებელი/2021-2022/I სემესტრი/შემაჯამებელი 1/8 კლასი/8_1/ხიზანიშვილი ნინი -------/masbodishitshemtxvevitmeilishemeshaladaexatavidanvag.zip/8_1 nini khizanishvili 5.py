#5
import math
x1=5
x2=8
y1=3
y2=2

print(math sprt((x2-x1)**2 +(y2-y1)**2))
