#2
   kms=14.0
   miles=kms/1.6
   minutes=45.5

   miles_in_1 _minutes=miles/minutes
   miles_in_1_hour=miles_in_1_minute*60

print(str(miles_in_1_hour)+miles/hour)
