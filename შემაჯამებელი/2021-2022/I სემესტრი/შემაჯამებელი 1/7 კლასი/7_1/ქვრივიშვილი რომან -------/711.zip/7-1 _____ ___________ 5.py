x1=76
x2=109
y1=65
y2=78
import math
z=(x2-x1)**2*(y2-y1)**2
print(math.sqrt(z))

