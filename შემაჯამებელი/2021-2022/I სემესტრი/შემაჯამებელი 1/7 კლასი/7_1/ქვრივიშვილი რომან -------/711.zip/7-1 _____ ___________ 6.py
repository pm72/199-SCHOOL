num1=12.512-3.98j
r=num1.real
i=num1.imag
print((r+i)/2)


