x=14
t=45.5
k=1.6
v=(x/k)/(t/60)
print(v)


