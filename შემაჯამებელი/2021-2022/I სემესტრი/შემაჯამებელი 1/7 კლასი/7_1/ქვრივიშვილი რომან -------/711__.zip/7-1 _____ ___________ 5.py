##mas ver gavige pirobashi ras gvekitxebodnen
