import random
n = random.randint(100,999)
x=n/60
print(n,x)
