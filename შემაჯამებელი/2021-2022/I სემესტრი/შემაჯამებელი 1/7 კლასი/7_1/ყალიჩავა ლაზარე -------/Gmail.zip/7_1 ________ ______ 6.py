num1 = 12.512 - 3.98j
print(num1)

world  =  num1 / 2
print(world)
