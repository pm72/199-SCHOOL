a=2.59
b=-8.92
d=(2*b)/(a**b)
c=(a-2*b)/(d**2)
d=(2*b)/(a**b)
r=(2.79*a+3*d)/(b**2-2*a*c)
num1=4/(3*(r+34))

num2=9*(a+b*c)

num3=(3+d*(2+a))/(a+b*d)

print(num1-num2+num3)
