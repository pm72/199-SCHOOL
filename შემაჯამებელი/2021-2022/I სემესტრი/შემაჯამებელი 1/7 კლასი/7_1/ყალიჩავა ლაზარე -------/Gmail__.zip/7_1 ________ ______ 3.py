import  random
num1 = random.randint(100, 999)
num2 = random.randint(1, 60)
num3 = random.randint(1, 60)
print(num1, num2, num3)
