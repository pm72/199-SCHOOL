num1 = 14/1.6
num2 = 2730
hi = num1 / num2
print(hi)

world = hi * 3600
print(world)
