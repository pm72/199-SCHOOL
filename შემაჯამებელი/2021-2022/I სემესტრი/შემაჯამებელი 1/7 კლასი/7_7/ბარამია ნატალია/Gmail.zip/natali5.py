import math

x1=3

x2=4

y1=9

y2=17

print(math.sqrt((x2-x1) ** 2+ (y2-y1) ** 2))
