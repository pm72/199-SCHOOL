a=12.512

b=3.98j

c=a-b

d=c.real

e= c.imag

print((d+e)/2)
