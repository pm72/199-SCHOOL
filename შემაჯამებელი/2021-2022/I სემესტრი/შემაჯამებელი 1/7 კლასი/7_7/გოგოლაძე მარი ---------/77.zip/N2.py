Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
x=14 / 1.6
s = 45*60+30
h=s/3600
print(x/h, "miles/hour")
11.538461538461538 miles/hour
