Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
a=2.59
b=8.92
d=2*b/(a**b)
c=(a-2*b)/(d**2)
r=(2.79*a+3*d)/(b**2-2*a*c)
print(4/(3*(r+34))-9*(a+b*c)+3+d*(2+1)/(a+b*d))
90856332.42041118
