Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import math
m=13
n=56
z=34
y=27
a=((m-n)**2)+((z-y)**2)
print(math.sqrt(a))
43.56604182158393
