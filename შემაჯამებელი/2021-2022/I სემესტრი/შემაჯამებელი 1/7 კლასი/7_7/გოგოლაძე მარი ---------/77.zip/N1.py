Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
(9.5 * 4.5 - 2.5 * 3 / (45.5 - 3.5))
42.57142857142857
