Python 3.10.0 (tags/v3.10.0:b494f59, Oct  4 2021, 19:00:18) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
import random
n=(random.choice([400, 5000, 740, 362]))
a=n//60
b=n%60
print(n)
5000
print(a,"wuti"," ", b,"wami")
83 wuti   20 wami
