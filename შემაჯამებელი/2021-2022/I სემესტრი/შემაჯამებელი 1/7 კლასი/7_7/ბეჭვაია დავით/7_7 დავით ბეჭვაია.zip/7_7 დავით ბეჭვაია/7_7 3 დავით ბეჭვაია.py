import random

num1 = random.randrange(100,999)
num2 = 60
print(num1)

sum = num1 / num2

import math

num3 = (math.floor(sum))
print(num3)

num4 = num1 - num3 * num2
print(num4)
