sum = 14 / 45.5
print(sum)

sum  = 0.3076923076923077 * 60
print(sum)

sum = 18.461538461538463 / 1.6
print(sum)
