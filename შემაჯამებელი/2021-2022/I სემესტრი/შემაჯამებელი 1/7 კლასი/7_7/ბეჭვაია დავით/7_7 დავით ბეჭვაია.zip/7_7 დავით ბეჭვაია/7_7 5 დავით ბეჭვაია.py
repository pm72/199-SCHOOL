import random
import math

x = (random.randrange(1, 1000))
y = (random.randrange(1, 1000))
x2 = (random.randrange(1, 1000))
y2 = (random.randrange(1, 1000))
sum = (x2 - x) ** 2 + (y2 - y) ** 2
print(sum)

print(math.sqrt((x2 - x) ** 2 + (y2 - y) ** 2))
