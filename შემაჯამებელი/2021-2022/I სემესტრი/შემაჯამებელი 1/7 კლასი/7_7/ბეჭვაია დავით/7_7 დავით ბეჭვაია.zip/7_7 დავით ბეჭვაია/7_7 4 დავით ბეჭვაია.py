import math

a = 2.59
b = -8.92
d = 2 * b / a ** b
c = (a - 2 * b) / d * d
r = (2.79 * a + 3 * d) /(b * b - 2 * a * c)



sum = 4 / (3 * (r + 34)) - 9 * (a + b * c) + 3 + d * (2 + a) / a + b * d
print(sum)
